Document Title:                 Explanation of Foundation Diagram Source
Document Owner:                 AUTOSAR
Document Responsibility:        AUTOSAR
Document Identification Number: 877
Document Status:                Final
Part of AUTOSAR Standard:       Foundation
Part of Standard Release:       1.5.0
Date:                           2018-10-31
